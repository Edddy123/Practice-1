# Practice

![photo5884151762011666154](https://user-images.githubusercontent.com/55801713/120153716-fa3ef180-c1e6-11eb-8e93-877f6e233c3d.jpg)

# Features
No Responsiveness

HTML and CSS

# Variables
--primary-color: #0078c4;

--bg-color: rgba(238, 238, 238, 0.50);

--text-color: rgba(0, 0, 0, 0.856);

# Font
Family: Quicksand 

# Images
Assets folder

# Icon
Font Awesome
